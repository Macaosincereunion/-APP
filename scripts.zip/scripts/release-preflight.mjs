import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import vm from "node:vm";

const appRoot = path.resolve(import.meta.dirname, "..");
const failures = [];
function fail(message) {
  failures.push(message);
}

const runtimeSource = fs.readFileSync(
  path.join(appRoot, "www", "runtime-config.js"),
  "utf8",
);
const sandbox = { window: {} };
vm.runInNewContext(runtimeSource, sandbox, { timeout: 1000 });
const config = sandbox.window.ZHONGKUI_CONFIG || {};
try {
  const url = new URL(config.purchaseVerificationUrl);
  if (url.protocol !== "https:" || !url.pathname.endsWith("/v1/google-play/verify")) {
    fail("purchaseVerificationUrl 必须是正式 HTTPS 验权接口");
  }
} catch {
  fail("purchaseVerificationUrl 尚未配置");
}
if (
  !config.entitlementKeyId ||
  config.entitlementPublicKeys?.[config.entitlementKeyId]?.kty !== "EC" ||
  config.entitlementPublicKeys?.[config.entitlementKeyId]?.crv !== "P-256" ||
  typeof config.entitlementPublicKeys?.[config.entitlementKeyId]?.x !== "string" ||
  typeof config.entitlementPublicKeys?.[config.entitlementKeyId]?.y !== "string"
) {
  fail("当前权益签名公钥尚未配置");
} else {
  try {
    crypto.createPublicKey({
      key: config.entitlementPublicKeys[config.entitlementKeyId],
      format: "jwk",
    });
  } catch {
    fail("当前权益签名公钥不是可导入的 P-256 JWK");
  }
}

for (const fileName of ["privacy-policy.html", "terms.html"]) {
  const content = fs.readFileSync(path.join(appRoot, "www", fileName), "utf8");
  if (/待填写|工程草案|不得作为正式上架|TO BE PROVIDED|engineering draft|MUST BE COMPLETED/i.test(content)) {
    fail(`${fileName} 仍包含待填写或草案文本`);
  }
}

for (const [name, value] of [
  ["PUBLIC_PRIVACY_POLICY_URL", process.env.PUBLIC_PRIVACY_POLICY_URL],
  ["PUBLIC_TERMS_URL", process.env.PUBLIC_TERMS_URL],
]) {
  try {
    if (new URL(value).protocol !== "https:") throw new Error();
  } catch {
    fail(`${name} 必须指向已公开部署的 HTTPS 页面`);
  }
}

const gradle = fs.readFileSync(
  path.join(appRoot, "android", "app", "build.gradle"),
  "utf8",
);
const versionCode = Number(gradle.match(/versionCode\s+(\d+)/)?.[1] || 0);
if (versionCode < 3) fail("正式新包的 versionCode 必须递增到至少 3");
if (!/targetSdkVersion\s*=\s*3[5-9]\b/.test(fs.readFileSync(path.join(appRoot, "android", "variables.gradle"), "utf8"))) {
  fail("Android targetSdkVersion 必须至少为 35");
}
if (!/android:usesCleartextTraffic="false"/.test(fs.readFileSync(path.join(appRoot, "android", "app", "src", "main", "AndroidManifest.xml"), "utf8"))) {
  fail("Android 必须明确禁止明文网络流量");
}
const keystorePropertiesPath = path.join(appRoot, "android", "keystore.properties");
const releaseKeystorePath = path.join(appRoot, "android", "zhongkui.keystore");
if (!fs.existsSync(keystorePropertiesPath) || !fs.existsSync(releaseKeystorePath)) {
  fail("正式 release 签名密钥或 keystore.properties 尚未配置");
}

const webRoot = path.join(appRoot, "www");
const androidWebRoot = path.join(
  appRoot,
  "android",
  "app",
  "src",
  "main",
  "assets",
  "public",
);
for (const fileName of fs.readdirSync(webRoot)) {
  const sourcePath = path.join(webRoot, fileName);
  if (!fs.statSync(sourcePath).isFile()) continue;
  const targetPath = path.join(androidWebRoot, fileName);
  if (!fs.existsSync(targetPath)) {
    fail(`Android 尚未同步 ${fileName}`);
    continue;
  }
  const hash = (filePath) =>
    crypto.createHash("sha256").update(fs.readFileSync(filePath)).digest("hex");
  if (hash(sourcePath) !== hash(targetPath)) {
    fail(`Android 中的 ${fileName} 不是最新版本，请运行 npx cap sync android`);
  }
}

if (failures.length) {
  process.stderr.write(
    "发布预检未通过：\n" + failures.map((item) => `- ${item}`).join("\n") + "\n",
  );
  process.exit(1);
}
process.stdout.write("发布预检通过\n");
