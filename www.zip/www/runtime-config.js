// 此文件由 server/deploy-cloud-run.ps1 生成；只包含公开配置，不含私钥。
window.ZHONGKUI_CONFIG = Object.freeze({
  purchaseVerificationUrl: "https://gongdao-entitlement-52kur7uroa-df.a.run.app/v1/google-play/verify",
  entitlementKeyId: "entitlement-v1",
  entitlementPublicKeys: Object.freeze({
  "entitlement-v1": {
    "kty": "EC",
    "crv": "P-256",
    "x": "y0S1Javrm15oC-kJJ6vquSgfhu2Mq5z2AtmBE0g-NWo",
    "y": "mI85uTqIlkqs_WmzRHNv_moq3y73UcAwRiFvkPliZoQ",
    "ext": true
  }
}),
});
